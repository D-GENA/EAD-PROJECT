namespace WinFormsApp1
{
    public class User
    {
        public int UserID { get; set; }
        public string Username { get; set; } = "";
        public string Password { get; set; } = "";
        public string Role { get; set; } = "";
    }

    public class Customer
    {
        public int CustomerID { get; set; }
        public string FirstName { get; set; } = "";
        public string LastName { get; set; } = "";
        public string NationalID { get; set; } = "";
        public string PhoneNumber { get; set; } = "";
        public string Email { get; set; } = "";
        public string Address { get; set; } = "";
        public string EmploymentStatus { get; set; } = "";
        public decimal MonthlyIncome { get; set; }
        public string FullName => $"{FirstName} {LastName}";
    }

    public class Loan
    {
        public int LoanID { get; set; }
        public int CustomerID { get; set; }
        public string CustomerName { get; set; } = "";
        public decimal LoanAmount { get; set; }
        public decimal InterestRate { get; set; }
        public int LoanTermMonths { get; set; }
        public DateTime ApplicationDate { get; set; }
        public string Status { get; set; } = "";
        public decimal RemainingBalance { get; set; }
    }

    public class Payment
    {
        public int PaymentID { get; set; }
        public int LoanID { get; set; }
        public DateTime PaymentDate { get; set; }
        public decimal AmountPaid { get; set; }
        public decimal RemainingBalance { get; set; }
    }
}
