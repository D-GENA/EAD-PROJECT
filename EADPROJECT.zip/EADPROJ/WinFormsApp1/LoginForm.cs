namespace WinFormsApp1
{
    public class LoginForm : Form
    {
        private Label    lblTitle    = new();
        private Label    lblSub      = new();
        private Label    lblUsername = new();
        private Label    lblPassword = new();
        private Label    lblRole     = new();
        private TextBox  txtUsername = new();
        private TextBox  txtPassword = new();
        private ComboBox cboRole     = new();
        private Button   btnLogin    = new();
        private Button   btnClear    = new();
        private Label    lblError    = new();
        private Panel    pnlCard     = new();

        public LoginForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            // ── Form ──────────────────────────────────────────────────────────
            Text            = "Loan Management System";
            ClientSize      = new Size(460, 540);
            StartPosition   = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox     = false;
            BackColor       = Color.FromArgb(22, 52, 110);

            // ── Header ────────────────────────────────────────────────────────
            lblTitle.Text      = "🏦  Loan Management System";
            lblTitle.Font      = new Font("Segoe UI", 15, FontStyle.Bold);
            lblTitle.ForeColor = Color.White;
            lblTitle.AutoSize  = false;
            lblTitle.Size      = new Size(440, 36);
            lblTitle.Location  = new Point(10, 28);
            lblTitle.TextAlign = ContentAlignment.MiddleCenter;

            lblSub.Text      = "Please sign in to continue";
            lblSub.Font      = new Font("Segoe UI", 9);
            lblSub.ForeColor = Color.FromArgb(180, 210, 255);
            lblSub.AutoSize  = false;
            lblSub.Size      = new Size(440, 20);
            lblSub.Location  = new Point(10, 66);
            lblSub.TextAlign = ContentAlignment.MiddleCenter;

            // ── White card ────────────────────────────────────────────────────
            pnlCard.BackColor = Color.White;
            pnlCard.Size      = new Size(380, 390);
            pnlCard.Location  = new Point(40, 105);

            // ── Username ──────────────────────────────────────────────────────
            lblUsername.Text      = "Username";
            lblUsername.Font      = new Font("Segoe UI", 9, FontStyle.Bold);
            lblUsername.ForeColor = Color.FromArgb(80, 80, 80);
            lblUsername.AutoSize  = true;
            lblUsername.Location  = new Point(30, 30);

            txtUsername.Location    = new Point(30, 52);
            txtUsername.Size        = new Size(320, 32);
            txtUsername.Font        = new Font("Segoe UI", 11);
            txtUsername.BorderStyle = BorderStyle.FixedSingle;
            txtUsername.BackColor   = Color.FromArgb(245, 247, 252);

            // ── Password ──────────────────────────────────────────────────────
            lblPassword.Text      = "Password";
            lblPassword.Font      = new Font("Segoe UI", 9, FontStyle.Bold);
            lblPassword.ForeColor = Color.FromArgb(80, 80, 80);
            lblPassword.AutoSize  = true;
            lblPassword.Location  = new Point(30, 100);

            txtPassword.Location     = new Point(30, 122);
            txtPassword.Size         = new Size(320, 32);
            txtPassword.Font         = new Font("Segoe UI", 11);
            txtPassword.PasswordChar = '●';
            txtPassword.BorderStyle  = BorderStyle.FixedSingle;
            txtPassword.BackColor    = Color.FromArgb(245, 247, 252);

            // ── Role ──────────────────────────────────────────────────────────
            lblRole.Text      = "Role";
            lblRole.Font      = new Font("Segoe UI", 9, FontStyle.Bold);
            lblRole.ForeColor = Color.FromArgb(80, 80, 80);
            lblRole.AutoSize  = true;
            lblRole.Location  = new Point(30, 170);

            cboRole.Location      = new Point(30, 192);
            cboRole.Size          = new Size(320, 32);
            cboRole.Font          = new Font("Segoe UI", 11);
            cboRole.DropDownStyle = ComboBoxStyle.DropDownList;
            cboRole.FlatStyle     = FlatStyle.Flat;
            cboRole.Items.AddRange(new object[] { "-- Select Role --", "Admin", "Manager", "Clerk","Creator" });
            cboRole.SelectedIndex = 0;

            // ── Error ─────────────────────────────────────────────────────────
            lblError.Location  = new Point(30, 240);
            lblError.Size      = new Size(320, 18);
            lblError.Font      = new Font("Segoe UI", 8.5f);
            lblError.ForeColor = Color.Crimson;

            // ── Login button ──────────────────────────────────────────────────
            btnLogin.Text      = "LOGIN";
            btnLogin.Location  = new Point(30, 268);
            btnLogin.Size      = new Size(320, 44);
            btnLogin.Font      = new Font("Segoe UI", 11, FontStyle.Bold);
            btnLogin.BackColor = Color.FromArgb(22, 52, 110);
            btnLogin.ForeColor = Color.White;
            btnLogin.FlatStyle = FlatStyle.Flat;
            btnLogin.FlatAppearance.BorderSize = 0;
            btnLogin.Cursor    = Cursors.Hand;
            btnLogin.Click    += BtnLogin_Click;

            // ── Clear button ──────────────────────────────────────────────────
            btnClear.Text      = "Clear Fields";
            btnClear.Location  = new Point(30, 324);
            btnClear.Size      = new Size(320, 34);
            btnClear.Font      = new Font("Segoe UI", 9);
            btnClear.BackColor = Color.White;
            btnClear.ForeColor = Color.FromArgb(100, 100, 100);
            btnClear.FlatStyle = FlatStyle.Flat;
            btnClear.FlatAppearance.BorderColor = Color.FromArgb(200, 200, 200);
            btnClear.Cursor    = Cursors.Hand;
            btnClear.Click    += BtnClear_Click;

            // ── Assemble ──────────────────────────────────────────────────────
            pnlCard.Controls.AddRange(new Control[]
            {
                lblUsername, txtUsername,
                lblPassword, txtPassword,
                lblRole,     cboRole,
                lblError,    btnLogin, btnClear
            });

            Controls.AddRange(new Control[] { lblTitle, lblSub, pnlCard });
        }

        private void BtnLogin_Click(object? sender, EventArgs e)
        {
            lblError.Text = "";

            if (string.IsNullOrWhiteSpace(txtUsername.Text))
            { lblError.Text = "⚠  Username is required."; return; }

            if (string.IsNullOrWhiteSpace(txtPassword.Text))
            { lblError.Text = "⚠  Password is required."; return; }

            if (cboRole.SelectedIndex == 0)
            { lblError.Text = "⚠  Please select a role."; return; }

            var user = DataStore.Users.FirstOrDefault(u =>
                u.Username.Equals(txtUsername.Text.Trim(), StringComparison.OrdinalIgnoreCase) &&
                u.Password == txtPassword.Text &&
                u.Role     == cboRole.SelectedItem!.ToString());

            if (user == null)
            { lblError.Text = "⚠  Invalid login credentials."; return; }

            DataStore.CurrentUser = user;
            new DashboardForm().Show();
            Hide();
        }

        private void BtnClear_Click(object? sender, EventArgs e)
        {
            txtUsername.Clear();
            txtPassword.Clear();
            cboRole.SelectedIndex = 0;
            lblError.Text = "";
            txtUsername.Focus();
        }
    }
}
