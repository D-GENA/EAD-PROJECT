using System;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public class CustomerForm : Form
    {
        // 🔷 Dashboard UI Elements
        private MenuStrip menuStrip = new();
        private StatusStrip statusStrip = new();
        private ToolStripStatusLabel lblUser = new();
        private ToolStripStatusLabel lblDate = new();
        private ToolStripStatusLabel lblTime = new();
        private ToolStripStatusLabel lblStatus = new();
        private System.Windows.Forms.Timer clock = new();

        // 🔷 Existing Controls
        private TextBox txtCustomerID = new();
        private TextBox txtFirstName = new();
        private TextBox txtLastName = new();
        private TextBox txtNationalID = new();
        private TextBox txtPhone = new();
        private TextBox txtEmail = new();
        private TextBox txtAddress = new();
        private ComboBox cboEmployment = new();
        private TextBox txtMonthlyIncome = new();
        private DataGridView dgvCustomers = new();
        private Button btnSave = new();
        private Button btnClear = new();
        private Button btnDelete = new();

        public CustomerForm()
        {
            InitializeComponent();
            LoadGrid();
        }

        private void InitializeComponent()
        {
            Text = "Loan Management System – Customers";
            Size = new Size(900, 600);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(235, 240, 248);

            BuildMenu();
            BuildStatusStrip();
            BuildUI();
            StartClock();
        }

        // 🔷 MENU (same as Dashboard)
        private void BuildMenu()
        {
            menuStrip.BackColor = Color.FromArgb(30, 80, 160);
            menuStrip.ForeColor = Color.White;
            menuStrip.Font = new Font("Segoe UI", 10);

            var mnuCustomers = CreateMenuItem("👤 Customers");

            var mnuLoans = CreateMenuItem("📋 Loans");
            mnuLoans.Click += (s, e) => OpenAndClose(new LoanForm());

            var mnuPayments = CreateMenuItem("💳 Payments");
            mnuPayments.Click += (s, e) => OpenAndClose(new PaymentForm());

            var mnuReports = CreateMenuItem("📊 Reports");
            mnuReports.Click += (s, e) => OpenAndClose(new ReportsForm());

            var mnuSystem = new ToolStripMenuItem("⚙ System") { ForeColor = Color.White };

            var itmLogout = new ToolStripMenuItem("Logout");
            itmLogout.Click += BtnLogout_Click;

            var itmExit = new ToolStripMenuItem("Exit");
            itmExit.Click += (s, e) => Application.Exit();

            mnuSystem.DropDownItems.AddRange(new ToolStripItem[]
            {
                itmLogout,
                new ToolStripSeparator(),
                itmExit
            });

            menuStrip.Items.AddRange(new ToolStripItem[]
            {
                mnuCustomers, mnuLoans, mnuPayments, mnuReports, mnuSystem
            });

            MainMenuStrip = menuStrip;
            Controls.Add(menuStrip);
        }

        private ToolStripMenuItem CreateMenuItem(string text)
            => new(text) { ForeColor = Color.White };

        private void OpenAndClose(Form form)
        {
            form.StartPosition = FormStartPosition.CenterScreen;
            form.Show();
            this.Close();
        }

        // 🔷 STATUS BAR
        private void BuildStatusStrip()
        {
            lblUser.Text = $" 👤 {DataStore.CurrentUser!.Username} ({DataStore.CurrentUser.Role})";
            lblDate.Text = $" 📅 {DateTime.Today:dd-MMM-yyyy}";
            lblTime.Text = $" 🕐 {DateTime.Now:HH:mm:ss}";
            lblStatus.Text = " 👤 Customer Module";

            statusStrip.Items.AddRange(new ToolStripItem[]
            {
                lblUser, new ToolStripSeparator(),
                lblDate, new ToolStripSeparator(),
                lblTime, new ToolStripSeparator(),
                lblStatus
            });

            statusStrip.BackColor = Color.FromArgb(30, 80, 160);

            foreach (ToolStripItem item in statusStrip.Items)
                item.ForeColor = Color.White;

            Controls.Add(statusStrip);
        }

        // 🔷 MAIN UI
        private void BuildUI()
        {
            var fields = new (string Label, Control Ctrl)[]
            {
                ("Customer ID", txtCustomerID),
                ("First Name *", txtFirstName),
                ("Last Name *", txtLastName),
                ("National ID / TRN *", txtNationalID),
                ("Phone Number *", txtPhone),
                ("Email *", txtEmail),
                ("Address *", txtAddress),
                ("Employment Status", cboEmployment),
                ("Monthly Income *", txtMonthlyIncome)
            };

            int y = 40;

            foreach (var (lbl, ctrl) in fields)
            {
                Controls.Add(new Label
                {
                    Text = lbl,
                    Location = new Point(10, y + 3),
                    AutoSize = true
                });

                ctrl.Location = new Point(180, y);
                ctrl.Width = 220;
                Controls.Add(ctrl);

                y += 34;
            }

            txtCustomerID.Text = DataStore.NextCustomerID.ToString();
            txtCustomerID.ReadOnly = true;
            txtCustomerID.BackColor = Color.LightGray;

            cboEmployment.DropDownStyle = ComboBoxStyle.DropDownList;
            cboEmployment.Items.AddRange(new object[]
            {
                "Employed", "Self-Employed", "Unemployed", "Retired", "Student"
            });
            cboEmployment.SelectedIndex = 0;

            btnSave = MakeButton("Save", Color.Green, new Point(180, y));
            btnClear = MakeButton("Clear", Color.Gray, new Point(280, y));
            btnDelete = MakeButton("Delete", Color.Red, new Point(380, y));

            btnSave.Click += BtnSave_Click;
            btnClear.Click += BtnClear_Click;
            btnDelete.Click += BtnDelete_Click;

            Controls.AddRange(new Control[] { btnSave, btnClear, btnDelete });

            dgvCustomers.Location = new Point(10, y + 50);
            dgvCustomers.Size = new Size(860, 250);
            dgvCustomers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvCustomers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvCustomers.SelectionChanged += DgvCustomers_SelectionChanged;

            Controls.Add(dgvCustomers);
        }

        private void StartClock()
        {
            clock.Interval = 1000;
            clock.Tick += (s, e) =>
                lblTime.Text = $" 🕐 {DateTime.Now:HH:mm:ss}";
            clock.Start();
        }

        // 🔷 LOGOUT
        private void BtnLogout_Click(object? sender, EventArgs e)
        {
            DataStore.CurrentUser = null;
            new LoginForm().Show();
            this.Close();
        }

        // 🔷 EXISTING LOGIC (UNCHANGED)
        private void LoadGrid()
        {
            dgvCustomers.DataSource = null;
            dgvCustomers.DataSource = DataStore.Customers.ToList();
        }

        private void DgvCustomers_SelectionChanged(object? sender, EventArgs e)
        {
            if (dgvCustomers.SelectedRows.Count == 0) return;

            int id = Convert.ToInt32(dgvCustomers.SelectedRows[0].Cells["CustomerID"].Value);
            var c = DataStore.Customers.FirstOrDefault(x => x.CustomerID == id);
            if (c == null) return;

            txtCustomerID.Text = c.CustomerID.ToString();
            txtFirstName.Text = c.FirstName;
            txtLastName.Text = c.LastName;
            txtNationalID.Text = c.NationalID;
            txtPhone.Text = c.PhoneNumber;
            txtEmail.Text = c.Email;
            txtAddress.Text = c.Address;
            cboEmployment.Text = c.EmploymentStatus;
            txtMonthlyIncome.Text = c.MonthlyIncome.ToString("F2");
        }

        private bool ValidateForm(out string error)
        {
            error = "";

            if (string.IsNullOrWhiteSpace(txtFirstName.Text))
            {
                error = "First name is required.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtLastName.Text))
            {
                error = "Last name is required.";
                return false;
            }

            if (!Regex.IsMatch(txtPhone.Text, @"^\d+$"))
            {
                error = "Phone must be numeric.";
                return false;
            }

            if (!txtEmail.Text.Contains("@") || !txtEmail.Text.Contains("."))
            {
                error = "Invalid email.";
                return false;
            }

            if (!decimal.TryParse(txtMonthlyIncome.Text, out decimal inc) || inc <= 0)
            {
                error = "Invalid income.";
                return false;
            }

            return true;
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            if (!ValidateForm(out string err))
            {
                MessageBox.Show(err);
                return;
            }

            int id = int.Parse(txtCustomerID.Text);

            DataStore.Customers.RemoveAll(c => c.CustomerID == id);

            DataStore.Customers.Add(new Customer
            {
                CustomerID = id,
                FirstName = txtFirstName.Text,
                LastName = txtLastName.Text,
                NationalID = txtNationalID.Text,
                PhoneNumber = txtPhone.Text,
                Email = txtEmail.Text,
                Address = txtAddress.Text,
                EmploymentStatus = cboEmployment.Text,
                MonthlyIncome = decimal.Parse(txtMonthlyIncome.Text)
            });

            MessageBox.Show("Saved!");
            BtnClear_Click(null, EventArgs.Empty);
            LoadGrid();
        }

        private void BtnClear_Click(object? sender, EventArgs e)
        {
            txtCustomerID.Text = DataStore.NextCustomerID.ToString();
            txtFirstName.Clear();
            txtLastName.Clear();
            txtNationalID.Clear();
            txtPhone.Clear();
            txtEmail.Clear();
            txtAddress.Clear();
            txtMonthlyIncome.Clear();
            cboEmployment.SelectedIndex = 0;
        }

        private void BtnDelete_Click(object? sender, EventArgs e)
        {
            if (dgvCustomers.SelectedRows.Count == 0) return;

            int id = Convert.ToInt32(dgvCustomers.SelectedRows[0].Cells["CustomerID"].Value);
            DataStore.Customers.RemoveAll(c => c.CustomerID == id);
            LoadGrid();
        }

        private static Button MakeButton(string text, Color color, Point loc)
            => new()
            {
                Text = text,
                Location = loc,
                BackColor = color,
                ForeColor = Color.White,
                Width = 90
            };
    }
}