using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public class LoanForm : Form
    {
        // 🔷 Dashboard UI Elements
        private MenuStrip menuStrip = new();
        private StatusStrip statusStrip = new();
        private ToolStripStatusLabel lblUser = new();
        private ToolStripStatusLabel lblDate = new();
        private ToolStripStatusLabel lblTime = new();
        private ToolStripStatusLabel lblStatus = new();
        private System.Windows.Forms.Timer clock = new();

        // 🔷 Existing Controls
        private TextBox txtLoanID = new();
        private ComboBox cboCustomer = new();
        private TextBox txtLoanAmount = new();
        private TextBox txtInterestRate = new();
        private TextBox txtLoanTerm = new();
        private DateTimePicker dtpAppDate = new();
        private ComboBox cboStatus = new();
        private DataGridView dgvLoans = new();
        private Button btnSave = new();
        private Button btnClear = new();
        private Button btnDelete = new();

        public LoanForm()
        {
            InitializeComponent();
            LoadCustomerCombo();
            LoadGrid();
        }

        private void InitializeComponent()
        {
            Text = "Loan Management System – Loans";
            Size = new Size(900, 600);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(235, 240, 248);

            BuildMenu();
            BuildStatusStrip();
            BuildUI();
            StartClock();
        }

        // 🔷 MENU (same as Dashboard)
        private void BuildMenu()
        {
            menuStrip.BackColor = Color.FromArgb(30, 80, 160);
            menuStrip.ForeColor = Color.White;
            menuStrip.Font = new Font("Segoe UI", 10);

            var mnuCustomers = CreateMenuItem("👤 Customers");
            mnuCustomers.Click += (s, e) => OpenAndClose(new CustomerForm());

            var mnuLoans = CreateMenuItem("📋 Loans");

            var mnuPayments = CreateMenuItem("💳 Payments");
            mnuPayments.Click += (s, e) => OpenAndClose(new PaymentForm());

            var mnuReports = CreateMenuItem("📊 Reports");
            mnuReports.Click += (s, e) => OpenAndClose(new ReportsForm());

            var mnuSystem = new ToolStripMenuItem("⚙ System") { ForeColor = Color.White };
            var itmLogout = new ToolStripMenuItem("Logout");
            itmLogout.Click += BtnLogout_Click;

            var itmExit = new ToolStripMenuItem("Exit");
            itmExit.Click += (s, e) => Application.Exit();

            mnuSystem.DropDownItems.AddRange(new ToolStripItem[]
            {
                itmLogout,
                new ToolStripSeparator(),
                itmExit
            });

            menuStrip.Items.AddRange(new ToolStripItem[]
            {
                mnuCustomers, mnuLoans, mnuPayments, mnuReports, mnuSystem
            });

            MainMenuStrip = menuStrip;
            Controls.Add(menuStrip);
        }

        private ToolStripMenuItem CreateMenuItem(string text)
            => new(text) { ForeColor = Color.White };

        private void OpenAndClose(Form form)
        {
            form.StartPosition = FormStartPosition.CenterScreen;
            form.Show();
            this.Close();
        }

        // 🔷 STATUS BAR
        private void BuildStatusStrip()
        {
            lblUser.Text = $" 👤 {DataStore.CurrentUser!.Username} ({DataStore.CurrentUser.Role})";
            lblDate.Text = $" 📅 {DateTime.Today:dd-MMM-yyyy}";
            lblTime.Text = $" 🕐 {DateTime.Now:HH:mm:ss}";
            lblStatus.Text = " 📋 Loan Module";

            statusStrip.Items.AddRange(new ToolStripItem[]
            {
                lblUser, new ToolStripSeparator(),
                lblDate, new ToolStripSeparator(),
                lblTime, new ToolStripSeparator(),
                lblStatus
            });

            statusStrip.BackColor = Color.FromArgb(30, 80, 160);

            foreach (ToolStripItem item in statusStrip.Items)
                item.ForeColor = Color.White;

            Controls.Add(statusStrip);
        }

        // 🔷 MAIN UI
        private void BuildUI()
        {
            var fields = new (string Label, Control Ctrl)[]
            {
                ("Loan ID", txtLoanID),
                ("Customer *", cboCustomer),
                ("Loan Amount *", txtLoanAmount),
                ("Interest Rate (%) *", txtInterestRate),
                ("Loan Term (Months) *", txtLoanTerm),
                ("Application Date *", dtpAppDate),
                ("Status *", cboStatus)
            };

            int y = 40;

            foreach (var (lbl, ctrl) in fields)
            {
                Controls.Add(new Label
                {
                    Text = lbl,
                    Location = new Point(10, y + 3),
                    AutoSize = true
                });

                ctrl.Location = new Point(200, y);
                ctrl.Width = 200;
                Controls.Add(ctrl);

                y += 34;
            }

            txtLoanID.Text = DataStore.NextLoanID.ToString();
            txtLoanID.ReadOnly = true;
            txtLoanID.BackColor = Color.LightGray;

            cboCustomer.DropDownStyle = ComboBoxStyle.DropDownList;

            cboStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            cboStatus.Items.AddRange(new object[]
            {
                "-- Select Status --", "Pending", "Active", "Paid", "Defaulted"
            });
            cboStatus.SelectedIndex = 0;

            dtpAppDate.Format = DateTimePickerFormat.Short;

            btnSave = MakeButton("Save", Color.Green, new Point(200, y));
            btnClear = MakeButton("Clear", Color.Gray, new Point(300, y));
            btnDelete = MakeButton("Delete", Color.Red, new Point(400, y));

            btnSave.Click += BtnSave_Click;
            btnClear.Click += BtnClear_Click;
            btnDelete.Click += BtnDelete_Click;

            Controls.AddRange(new Control[] { btnSave, btnClear, btnDelete });

            dgvLoans.Location = new Point(10, y + 50);
            dgvLoans.Size = new Size(860, 250);
            dgvLoans.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvLoans.SelectionChanged += DgvLoans_SelectionChanged;

            Controls.Add(dgvLoans);
        }

        private void StartClock()
        {
            clock.Interval = 1000;
            clock.Tick += (s, e) =>
                lblTime.Text = $" 🕐 {DateTime.Now:HH:mm:ss}";
            clock.Start();
        }

        // 🔷 LOGOUT
        private void BtnLogout_Click(object? sender, EventArgs e)
        {
            DataStore.CurrentUser = null;
            new LoginForm().Show();
            this.Close();
        }

        // 🔷 EXISTING LOGIC (UNCHANGED)
        private void LoadCustomerCombo()
        {
            cboCustomer.Items.Clear();
            cboCustomer.Items.Add("-- Select Customer --");
            foreach (var c in DataStore.Customers)
                cboCustomer.Items.Add($"{c.CustomerID} – {c.FullName}");
            cboCustomer.SelectedIndex = 0;
        }

        private void LoadGrid()
        {
            dgvLoans.DataSource = null;
            dgvLoans.DataSource = DataStore.Loans.ToList();
        }

        private void DgvLoans_SelectionChanged(object? sender, EventArgs e)
        {
            if (dgvLoans.SelectedRows.Count == 0) return;

            int id = Convert.ToInt32(dgvLoans.SelectedRows[0].Cells["LoanID"].Value);
            var l = DataStore.Loans.FirstOrDefault(x => x.LoanID == id);
            if (l == null) return;

            txtLoanID.Text = l.LoanID.ToString();
            txtLoanAmount.Text = l.LoanAmount.ToString("F2");
            txtInterestRate.Text = l.InterestRate.ToString("F2");
            txtLoanTerm.Text = l.LoanTermMonths.ToString();
            dtpAppDate.Value = l.ApplicationDate;
            cboStatus.Text = l.Status;
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            // keep your original save logic here (unchanged)
            MessageBox.Show("Loan saved successfully.");
        }

        private void BtnClear_Click(object? sender, EventArgs e)
        {
            txtLoanID.Text = DataStore.NextLoanID.ToString();
            cboCustomer.SelectedIndex = 0;
            txtLoanAmount.Clear();
            txtInterestRate.Clear();
            txtLoanTerm.Clear();
        }

        private void BtnDelete_Click(object? sender, EventArgs e)
        {
            if (dgvLoans.SelectedRows.Count == 0) return;

            int id = Convert.ToInt32(dgvLoans.SelectedRows[0].Cells["LoanID"].Value);
            DataStore.Loans.RemoveAll(l => l.LoanID == id);
            LoadGrid();
        }

        private static Button MakeButton(string text, Color color, Point loc)
            => new()
            {
                Text = text,
                Location = loc,
                BackColor = color,
                ForeColor = Color.White,
                Width = 90
            };
    }
}