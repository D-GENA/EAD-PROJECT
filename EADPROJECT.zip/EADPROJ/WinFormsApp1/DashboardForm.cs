namespace WinFormsApp1
{
    public class DashboardForm : Form
    {
        private MenuStrip   menuStrip  = new();
        private StatusStrip statusStrip = new();
        private ToolStripStatusLabel lblUser   = new();
        private ToolStripStatusLabel lblDate   = new();
        private ToolStripStatusLabel lblTime   = new();
        private ToolStripStatusLabel lblStatus = new();
        private System.Windows.Forms.Timer clock = new();
        private readonly Dictionary<string, Form> _openForms = new();

        public DashboardForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            Text           = "Loan Management System – Dashboard";
            Size           = new Size(900, 600);
            StartPosition  = FormStartPosition.CenterScreen;
            BackColor      = Color.FromArgb(235, 240, 248);
            IsMdiContainer = true;

            if (DataStore.CurrentUser == null)
            {
                MessageBox.Show("Please log in to access the system.", "Access Denied",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Close();
                return;
            }

            BuildMenu();
            BuildStatusStrip();
            BuildWelcomeBanner();
            StartClock();
        }

        private void BuildMenu()
        {
            menuStrip.BackColor = Color.FromArgb(30, 80, 160);
            menuStrip.ForeColor = Color.White;
            menuStrip.Font      = new Font("Segoe UI", 10);

            var mnuCustomers = CreateMenuItem("👤  Customers");
            mnuCustomers.Click += (s, e) => OpenForm("Customers", () => new CustomerForm());

            var mnuLoans = CreateMenuItem("📋  Loans");
            mnuLoans.Click += (s, e) => OpenForm("Loans", () => new LoanForm());

            var mnuPayments = CreateMenuItem("💳  Payments");
            mnuPayments.Click += (s, e) => OpenForm("Payments", () => new PaymentForm());

            var mnuReports = CreateMenuItem("📊  Reports");
            mnuReports.Click += (s, e) => OpenForm("Reports", () => new ReportsForm());
           // mnuReports.Click += (s, e) => OpenForm("Reports", () => new ReportsForm(this));

            var mnuSystem  = new ToolStripMenuItem("⚙  System") { ForeColor = Color.White };
            var itmLogout  = new ToolStripMenuItem("Logout");
            itmLogout.Click += BtnLogout_Click;
            var itmExit    = new ToolStripMenuItem("Exit");
            itmExit.Click  += BtnExit_Click;
            mnuSystem.DropDownItems.AddRange(new ToolStripItem[] { itmLogout, new ToolStripSeparator(), itmExit });

            menuStrip.Items.AddRange(new ToolStripItem[]
                { mnuCustomers, mnuLoans, mnuPayments, mnuReports, mnuSystem });

            MainMenuStrip = menuStrip;
            Controls.Add(menuStrip);
        }

        private static ToolStripMenuItem CreateMenuItem(string text)
            => new(text) { ForeColor = Color.White, Font = new Font("Segoe UI", 10) };

        /*private void OpenForm(string key, Func<Form> factory)
       {
            if (_openForms.TryGetValue(key, out var existing) && !existing.IsDisposed)
            {
                existing.WindowState = FormWindowState.Normal;
                existing.BringToFront();
                existing.Focus();
                return;
            }

            try
            {
                var form = factory();
                form.MdiParent = this;
                form.FormClosed += (s, e) => _openForms.Remove(key);
                _openForms[key] = form;

                form.Show();
                form.BringToFront(); // 🔥 ensures visibility
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Opening Form",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }*/



            private void OpenForm(string key, Func<Form> factory)
        {
            if (_openForms.TryGetValue(key, out var existing) && !existing.IsDisposed)
            {
                existing.BringToFront();
                return;
            }

            var form = factory();
            form.FormClosed += (s, e) => _openForms.Remove(key);

            _openForms[key] = form;
            form.StartPosition = FormStartPosition.CenterScreen;
            form.Show();

            this.Hide(); // hide dashboard
        }

        private void BuildStatusStrip()
        {
            lblUser.Text   = $"  👤 {DataStore.CurrentUser!.Username} ({DataStore.CurrentUser.Role})";
            lblDate.Text   = $"  📅 {DateTime.Today:dd-MMM-yyyy}";
            lblTime.Text   = $"  🕐 {DateTime.Now:HH:mm:ss}";
            lblStatus.Text = "  ✅ System Online";

            statusStrip.Items.AddRange(new ToolStripItem[]
            { lblUser, new ToolStripSeparator(), lblDate, new ToolStripSeparator(), lblTime, new ToolStripSeparator(), lblStatus });
            statusStrip.BackColor = Color.FromArgb(30, 80, 160);
            foreach (ToolStripItem item in statusStrip.Items)
                item.ForeColor = Color.White;

            Controls.Add(statusStrip);
        }

        private void BuildWelcomeBanner()
        {
            var pnl = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(235, 240, 248) };
            var lbl = new Label
            {
                Text      = $"Welcome, {DataStore.CurrentUser!.Username}!\n\nUse the menu above to navigate.",
                AutoSize  = false,
                Dock      = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                Font      = new Font("Segoe UI", 16, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 80, 160)
            };
            pnl.Controls.Add(lbl);
            Controls.Add(pnl);
            pnl.BringToFront();
        }

        private void StartClock()
        {
            clock.Interval = 1000;
            clock.Tick    += (s, e) => lblTime.Text = $"  🕐 {DateTime.Now:HH:mm:ss}";
            clock.Start();
        }

        private void BtnLogout_Click(object? sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to logout?", "Logout",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                DataStore.CurrentUser = null;
                clock.Stop();
                new LoginForm().Show();
                Close();
            }
        }

        private void BtnExit_Click(object? sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to exit the application?", "Exit",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                Application.Exit();
        }
    }
}
