using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public class PaymentForm : Form
    {
        private MenuStrip menuStrip = new();
        private StatusStrip statusStrip = new();
        private ToolStripStatusLabel lblUser = new();
        private ToolStripStatusLabel lblDate = new();
        private ToolStripStatusLabel lblTime = new();
        private ToolStripStatusLabel lblStatus = new();
        private System.Windows.Forms.Timer clock = new();

        private TextBox txtPaymentID = new();
        private ComboBox cboLoan = new();
        private DateTimePicker dtpPaymentDate = new();
        private TextBox txtAmountPaid = new();
        private TextBox txtRemainingBal = new();
        private DataGridView dgvPayments = new();
        private Button btnSave = new();
        private Button btnClear = new();

        public PaymentForm()
        {
            InitializeComponent();
            LoadLoanCombo();
            LoadGrid();
        }

        private void InitializeComponent()
        {
            Text = "Loan Management System – Payments";
            Size = new Size(900, 600);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(235, 240, 248);

            BuildMenu();
            BuildStatusStrip();
            BuildUI();
            StartClock();
        }

        // 🔥 SAME MENU AS DASHBOARD
        private void BuildMenu()
        {
            menuStrip.BackColor = Color.FromArgb(30, 80, 160);
            menuStrip.ForeColor = Color.White;
            menuStrip.Font = new Font("Segoe UI", 10);

            var mnuCustomers = CreateMenuItem("👤  Customers");
            mnuCustomers.Click += (s, e) => Navigate(new CustomerForm());

            var mnuLoans = CreateMenuItem("📋  Loans");
            mnuLoans.Click += (s, e) => Navigate(new LoanForm());

            var mnuPayments = CreateMenuItem("💳  Payments"); // current page

            var mnuReports = CreateMenuItem("📊  Reports");
            mnuReports.Click += (s, e) => Navigate(new ReportsForm());

            var mnuSystem = new ToolStripMenuItem("⚙  System") { ForeColor = Color.White };

            var itmLogout = new ToolStripMenuItem("Logout");
            itmLogout.Click += BtnLogout_Click;

            var itmExit = new ToolStripMenuItem("Exit");
            itmExit.Click += (s, e) => Application.Exit();

            mnuSystem.DropDownItems.AddRange(new ToolStripItem[]
            {
                itmLogout,
                new ToolStripSeparator(),
                itmExit
            });

            menuStrip.Items.AddRange(new ToolStripItem[]
            {
                mnuCustomers,
                mnuLoans,
                mnuPayments,
                mnuReports,
                mnuSystem
            });

            MainMenuStrip = menuStrip;
            Controls.Add(menuStrip);
        }

        private static ToolStripMenuItem CreateMenuItem(string text)
            => new(text) { ForeColor = Color.White };

        private void Navigate(Form form)
        {
            form.StartPosition = FormStartPosition.CenterScreen;
            form.Show();
            this.Close();
        }

        private void BuildStatusStrip()
        {
            lblUser.Text = $"  👤 {DataStore.CurrentUser!.Username} ({DataStore.CurrentUser.Role})";
            lblDate.Text = $"  📅 {DateTime.Today:dd-MMM-yyyy}";
            lblTime.Text = $"  🕐 {DateTime.Now:HH:mm:ss}";
            lblStatus.Text = "  💳 Payments Ready";

            statusStrip.Items.AddRange(new ToolStripItem[]
            {
                lblUser,
                new ToolStripSeparator(),
                lblDate,
                new ToolStripSeparator(),
                lblTime,
                new ToolStripSeparator(),
                lblStatus
            });

            statusStrip.BackColor = Color.FromArgb(30, 80, 160);

            foreach (ToolStripItem item in statusStrip.Items)
                item.ForeColor = Color.White;

            Controls.Add(statusStrip);
        }

        private void BuildUI()
        {
            var fields = new (string Label, Control Ctrl)[]
            {
                ("Payment ID",        txtPaymentID),
                ("Loan *",            cboLoan),
                ("Payment Date *",    dtpPaymentDate),
                ("Amount Paid *",     txtAmountPaid),
                ("Remaining Balance", txtRemainingBal)
            };

            int y = 50;

            foreach (var (lbl, ctrl) in fields)
            {
                Controls.Add(new Label
                {
                    Text = lbl,
                    Location = new Point(20, y + 3),
                    AutoSize = true,
                    Font = new Font("Segoe UI", 9)
                });

                ctrl.Location = new Point(200, y);
                ctrl.Width = 220;
                ctrl.Font = new Font("Segoe UI", 10);
                Controls.Add(ctrl);

                y += 34;
            }

            txtPaymentID.Text = DataStore.NextPaymentID.ToString();
            txtPaymentID.ReadOnly = true;
            txtPaymentID.BackColor = Color.LightGray;

            txtRemainingBal.ReadOnly = true;
            txtRemainingBal.BackColor = Color.LightGray;

            cboLoan.DropDownStyle = ComboBoxStyle.DropDownList;
            cboLoan.SelectionChangeCommitted += CboLoan_Changed;

            dtpPaymentDate.Format = DateTimePickerFormat.Short;
            dtpPaymentDate.MaxDate = DateTime.Today;

            btnSave = MakeButton("Save", Color.FromArgb(30, 130, 30), new Point(200, y + 5));
            btnClear = MakeButton("Clear", Color.FromArgb(100, 100, 100), new Point(295, y + 5));

            btnSave.Click += BtnSave_Click;
            btnClear.Click += BtnClear_Click;

            Controls.AddRange(new Control[] { btnSave, btnClear });

            dgvPayments.Location = new Point(20, y + 50);
            dgvPayments.Size = new Size(840, 220);
            dgvPayments.ReadOnly = true;
            dgvPayments.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvPayments.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvPayments.BackgroundColor = Color.White;

            Controls.Add(dgvPayments);
        }

        private void StartClock()
        {
            clock.Interval = 1000;
            clock.Tick += (s, e) =>
            {
                lblTime.Text = $"  🕐 {DateTime.Now:HH:mm:ss}";
            };
            clock.Start();
        }

        private void LoadLoanCombo()
        {
            cboLoan.Items.Clear();
            cboLoan.Items.Add("-- Select Loan --");

            foreach (var l in DataStore.Loans.Where(l => l.Status == "Active"))
                cboLoan.Items.Add($"{l.LoanID} – {l.CustomerName} (Bal: {l.RemainingBalance:C})");

            cboLoan.SelectedIndex = 0;
        }

        private void CboLoan_Changed(object? sender, EventArgs e)
        {
            if (cboLoan.SelectedIndex == 0)
            {
                txtRemainingBal.Text = "";
                return;
            }

            int loanId = int.Parse(cboLoan.Text.Split('–')[0].Trim());
            var loan = DataStore.Loans.FirstOrDefault(l => l.LoanID == loanId);

            if (loan != null)
                txtRemainingBal.Text = loan.RemainingBalance.ToString("F2");
        }

        private void LoadGrid()
        {
            dgvPayments.DataSource = null;
            dgvPayments.DataSource = DataStore.Payments.ToList();
        }

        private bool ValidateForm(out string error, out decimal amount, out Loan? loan)
        {
            error = ""; amount = 0; loan = null;

            if (cboLoan.SelectedIndex == 0) { error = "Select a loan."; return false; }
            if (!decimal.TryParse(txtAmountPaid.Text, out amount)) { error = "Invalid amount."; return false; }
            if (amount <= 0) { error = "Amount must be > 0."; return false; }

            int loanId = int.Parse(cboLoan.Text.Split('–')[0].Trim());
            loan = DataStore.Loans.FirstOrDefault(l => l.LoanID == loanId);

            if (loan != null && amount > loan.RemainingBalance)
            {
                error = "Amount exceeds balance.";
                return false;
            }

            return true;
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            if (!ValidateForm(out string err, out decimal amount, out Loan? loan))
            {
                MessageBox.Show(err);
                return;
            }

            loan!.RemainingBalance -= amount;
            if (loan.RemainingBalance <= 0) loan.Status = "Paid";

            DataStore.Payments.Add(new Payment
            {
                PaymentID = DataStore.NextPaymentID,
                LoanID = loan.LoanID,
                PaymentDate = dtpPaymentDate.Value,
                AmountPaid = amount,
                RemainingBalance = loan.RemainingBalance
            });

            MessageBox.Show("Payment saved.");
            BtnClear_Click(null, EventArgs.Empty);
            LoadLoanCombo();
            LoadGrid();
        }

        private void BtnClear_Click(object? sender, EventArgs e)
        {
            txtPaymentID.Text = DataStore.NextPaymentID.ToString();
            cboLoan.SelectedIndex = 0;
            dtpPaymentDate.Value = DateTime.Today;
            txtAmountPaid.Clear();
            txtRemainingBal.Text = "";
        }

        private void BtnLogout_Click(object sender, EventArgs e)
        {
            DataStore.CurrentUser = null;
            new LoginForm().Show();
            this.Close();
        }

        private static Button MakeButton(string text, Color back, Point loc)
            => new()
            {
                Text = text,
                Location = loc,
                Width = 90,
                BackColor = back,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
    }
}