
using System;
using System.Windows.Forms;

namespace WinFormsApp1
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            
            ApplicationConfiguration.Initialize();
            Application.Run(new LoginForm());

            while (true) // 🔥 keeps app restarting
            {
                try
                {
                    Application.Run(new LoginForm());
                    break; // exit loop if app closes normally
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"App crashed: {ex.Message}\nRestarting...");
                }
            }
        }
    }
}