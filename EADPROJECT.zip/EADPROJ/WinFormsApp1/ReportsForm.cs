﻿
/*using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class ReportsForm : Form
    {
        private ComboBox cmbReportType = new();
        private Button btnGenerate = new();
        private DataGridView dgvReport = new();
        private Label lblSummary = new();

        public ReportsForm()
        {
            InitializeComponent();
            SetupUI();
        }

        private void ReportsForm_Load(object sender, EventArgs e)
        {
            cmbReportType.SelectedIndex = 0;
        }

        private void SetupUI()
        {
            Text = "Reports Dashboard";
            Size = new Size(850, 550);
            BackColor = Color.FromArgb(30, 80, 160);

            // Report type
            cmbReportType.Items.AddRange(new string[]
            {
                "All Loans",
                "Active Loans",
                "Completed Loans",
                "Payments",
                "Total Outstanding Balance"
            });

            cmbReportType.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbReportType.Location = new Point(20, 20);
            cmbReportType.Width = 220;

            // Button
            btnGenerate.Text = "Generate";
            btnGenerate.Location = new Point(260, 18);
            btnGenerate.Click += BtnGenerate_Click;

            // Summary
            lblSummary.Location = new Point(20, 60);
            lblSummary.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            lblSummary.AutoSize = true;

            // Grid
            dgvReport.Location = new Point(20, 100);
            dgvReport.Size = new Size(780, 350);
            dgvReport.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            Controls.AddRange(new Control[] { cmbReportType, btnGenerate, lblSummary, dgvReport });
        }

        private void BtnGenerate_Click(object sender, EventArgs e)
        {
            string selected = cmbReportType.SelectedItem.ToString();

            switch (selected)
            {
                case "All Loans":
                    LoadLoans(DataStore.Loans);
                    break;

                case "Active Loans":
                    LoadLoans(DataStore.Loans.Where(l => l.Status == "Active").ToList());
                    break;

                case "Completed Loans":
                    LoadLoans(DataStore.Loans.Where(l => l.Status == "Paid").ToList());
                    break;

                case "Payments":
                    LoadPayments();
                    break;

                case "Total Outstanding Balance":
                    ShowOutstanding();
                    break;
            }
        }

        private void LoadLoans(System.Collections.Generic.List<Loan> loans)
        {
            dgvReport.DataSource = null;
            dgvReport.DataSource = loans;

            decimal totalLoanAmount = loans.Sum(l => l.LoanAmount);
            decimal totalRemaining = loans.Sum(l => l.RemainingBalance);

            lblSummary.Text = $"Loans: {loans.Count} | Total Loaned: {totalLoanAmount:C} | Remaining: {totalRemaining:C}";
        }

        private void LoadPayments()
        {
            dgvReport.DataSource = null;
            dgvReport.DataSource = DataStore.Payments;

            decimal totalPaid = DataStore.Payments.Sum(p => p.AmountPaid); 

            lblSummary.Text = $"Payments: {DataStore.Payments.Count} | Total Paid: {totalPaid:C}";
        }

        private void ShowOutstanding()
        {
            decimal totalRemaining = DataStore.Loans.Sum(l => l.RemainingBalance);

            dgvReport.DataSource = null;

            lblSummary.Text = $"Total Outstanding Balance: {totalRemaining:C}";
        }
    }
}

*/

// added a back buton to my 
using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public class ReportsForm : Form
    {
        private MenuStrip menuStrip = new();
        private StatusStrip statusStrip = new();
        private ToolStripStatusLabel lblUser = new();
        private ToolStripStatusLabel lblDate = new();
        private ToolStripStatusLabel lblTime = new();
        private ToolStripStatusLabel lblStatus = new();
        private System.Windows.Forms.Timer clock = new();

        private ComboBox cmbReportType = new();
        private Button btnGenerate = new();
        private DataGridView dgvReport = new();
        private Label lblSummary = new();

        public ReportsForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            Text = "Loan Management System – Reports";
            Size = new Size(900, 600);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(235, 240, 248);

            BuildMenu();
            BuildStatusStrip();
            BuildUI();
            StartClock();
        }

        // 🔥 SAME MENU AS DASHBOARD
        private void BuildMenu()
        {
            menuStrip.BackColor = Color.FromArgb(30, 80, 160);
            menuStrip.ForeColor = Color.White;
            menuStrip.Font = new Font("Segoe UI", 10);

            var mnuCustomers = CreateMenuItem("👤  Customers");
            mnuCustomers.Click += (s, e) => Navigate(new CustomerForm());

            var mnuLoans = CreateMenuItem("📋  Loans");
            mnuLoans.Click += (s, e) => Navigate(new LoanForm());

            var mnuPayments = CreateMenuItem("💳  Payments");
            mnuPayments.Click += (s, e) => Navigate(new PaymentForm());

            var mnuReports = CreateMenuItem("📊  Reports"); // current page

            var mnuSystem = new ToolStripMenuItem("⚙  System") { ForeColor = Color.White };
            var itmLogout = new ToolStripMenuItem("Logout");
            itmLogout.Click += BtnLogout_Click;

            var itmExit = new ToolStripMenuItem("Exit");
            itmExit.Click += (s, e) => Application.Exit();

            mnuSystem.DropDownItems.AddRange(new ToolStripItem[]
            {
                itmLogout,
                new ToolStripSeparator(),
                itmExit
            });

            menuStrip.Items.AddRange(new ToolStripItem[]
            {
                mnuCustomers,
                mnuLoans,
                mnuPayments,
                mnuReports,
                mnuSystem
            });

            MainMenuStrip = menuStrip;
            Controls.Add(menuStrip);
        }

        private static ToolStripMenuItem CreateMenuItem(string text)
            => new(text) { ForeColor = Color.White };

        // 🔥 NAVIGATION METHOD
        private void Navigate(Form form)
        {
            form.StartPosition = FormStartPosition.CenterScreen;
            form.Show();
            this.Close();
        }

        private void BuildStatusStrip()
        {
            lblUser.Text = $"  👤 {DataStore.CurrentUser!.Username} ({DataStore.CurrentUser.Role})";
            lblDate.Text = $"  📅 {DateTime.Today:dd-MMM-yyyy}";
            lblTime.Text = $"  🕐 {DateTime.Now:HH:mm:ss}";
            lblStatus.Text = "  📊 Reports Ready";

            statusStrip.Items.AddRange(new ToolStripItem[]
            {
                lblUser,
                new ToolStripSeparator(),
                lblDate,
                new ToolStripSeparator(),
                lblTime,
                new ToolStripSeparator(),
                lblStatus
            });

            statusStrip.BackColor = Color.FromArgb(30, 80, 160);

            foreach (ToolStripItem item in statusStrip.Items)
                item.ForeColor = Color.White;

            Controls.Add(statusStrip);
        }

        private void BuildUI()
        {
            cmbReportType.Items.AddRange(new string[]
            {
                "All Loans",
                "Active Loans",
                "Completed Loans",
                "Payments",
                "Outstanding Balance"
            });

            cmbReportType.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbReportType.Location = new Point(20, 60);
            cmbReportType.Width = 250;

            btnGenerate.Text = "Generate Report";
            btnGenerate.Location = new Point(290, 58);
            btnGenerate.Click += BtnGenerate_Click;

            lblSummary.Location = new Point(20, 100);
            lblSummary.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            lblSummary.ForeColor = Color.FromArgb(30, 80, 160);
            lblSummary.AutoSize = true;

            dgvReport.Location = new Point(20, 140);
            dgvReport.Size = new Size(840, 360);
            dgvReport.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            Controls.AddRange(new Control[]
            {
                cmbReportType,
                btnGenerate,
                lblSummary,
                dgvReport
            });
        }

        private void StartClock()
        {
            clock.Interval = 1000;
            clock.Tick += (s, e) =>
            {
                lblTime.Text = $"  🕐 {DateTime.Now:HH:mm:ss}";
            };
            clock.Start();
        }

        private void BtnGenerate_Click(object sender, EventArgs e)
        {
            string selected = cmbReportType.SelectedItem?.ToString();
            if (selected == null) return;

            switch (selected)
            {
                case "All Loans":
                    dgvReport.DataSource = DataStore.Loans;
                    lblSummary.Text = $"Total Loans: {DataStore.Loans.Count}";
                    break;

                case "Active Loans":
                    var active = DataStore.Loans.Where(l => l.Status == "Active").ToList();
                    dgvReport.DataSource = active;
                    lblSummary.Text = $"Active Loans: {active.Count}";
                    break;

                case "Completed Loans":
                    var completed = DataStore.Loans.Where(l => l.Status == "Paid").ToList();
                    dgvReport.DataSource = completed;
                    lblSummary.Text = $"Completed Loans: {completed.Count}";
                    break;

                case "Payments":
                    dgvReport.DataSource = DataStore.Payments;
                    lblSummary.Text = $"Payments: {DataStore.Payments.Count}";
                    break;

                case "Outstanding Balance":
                    decimal total = DataStore.Loans.Sum(l => l.RemainingBalance);
                    dgvReport.DataSource = null;
                    lblSummary.Text = $"Outstanding Balance: {total:C}";
                    break;
            }
        }

        private void BtnLogout_Click(object sender, EventArgs e)
        {
            DataStore.CurrentUser = null;
            new LoginForm().Show();
            this.Close();
        }
    }
}